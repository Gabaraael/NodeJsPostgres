'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
     
    await queryInterface.bulkInsert('Estudantes', 
    [{
        nome: 'John Doe',
        mail: 'doe@gmail.com',
        data_nascimento: "1998-12-05",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        nome: 'Wangley Viera',
        mail: 'msv10@gmail.com',
        data_nascimento: "1995-12-10",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        nome: 'Luana',
        mail: 'luana@gmail.com',
        data_nascimento: "1995-03-27",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
    
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
