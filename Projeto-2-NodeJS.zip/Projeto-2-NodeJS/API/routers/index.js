const estudantes = require('./EstudantesRoute');

/**
 * Sintaxe de uma função qualquer: function () {}
 * Sintaxe de uma arrow function: () => {}
 */

module.exports = app => {
    app.use(estudantes);
}
/** 
module.exports = function app(){
    app.use(estudantes);
}
**/