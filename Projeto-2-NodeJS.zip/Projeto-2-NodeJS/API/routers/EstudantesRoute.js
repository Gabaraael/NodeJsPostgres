//Importando o Router do express
//As chaves indicam que a propriedade Router de express será atribuída a uma constande de mesmo nome

const {Router} = require('express');
const EstudanteControllers = require('../controllers/EstudanteControllers');

const router = Router();
//Iniciando o Router da express
router.get('/estudantes', EstudanteControllers.pegaTodosOsEstudantes);
router.get('/estudantes/:id', EstudanteControllers.pegaUmEstudante);
router.post('/estudantes', EstudanteControllers.criaEstudante);
router.put('/estudantes/:id', EstudanteControllers.atualizaEstudante);
router.delete('/estudantes/:id', EstudanteControllers.apagarEstudante);
module.exports = router;
